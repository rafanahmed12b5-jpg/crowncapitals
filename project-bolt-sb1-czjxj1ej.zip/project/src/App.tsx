import Navigation from './components/Navigation';
import Hero from './components/Hero';
import About from './components/About';
import Focus from './components/Focus';
import Leadership from './components/Leadership';
import SellBusiness from './components/SellBusiness';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <Hero />
      <About />
      <Focus />
      <Leadership />
      <SellBusiness />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
