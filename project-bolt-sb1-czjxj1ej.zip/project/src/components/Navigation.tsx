import { Crown } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white shadow-md py-4' : 'bg-white shadow-md py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <button onClick={scrollToTop} className="flex items-center space-x-3">
          <Crown className="w-8 h-8 text-[#C8A951]" strokeWidth={1.5} />
          <div>
            <div className="font-bold text-xl tracking-tight transition-colors text-[#0A1A3F]">
              Crown Capitals
            </div>
            <div className="text-xs tracking-widest transition-colors text-gray-600">
              ACQUISITION LTD
            </div>
          </div>
        </button>

        <div className="hidden md:flex items-center space-x-8">
          <button
            onClick={() => scrollToSection('about')}
            className="font-medium transition-colors text-gray-700 hover:text-[#C8A951]"
          >
            About
          </button>
          <button
            onClick={() => scrollToSection('focus')}
            className="font-medium transition-colors text-gray-700 hover:text-[#C8A951]"
          >
            Our Focus
          </button>
          <button
            onClick={() => scrollToSection('leadership')}
            className="font-medium transition-colors text-gray-700 hover:text-[#C8A951]"
          >
            Leadership
          </button>
          <button
            onClick={() => scrollToSection('sell')}
            className="font-medium transition-colors text-gray-700 hover:text-[#C8A951]"
          >
            Sell Your Business
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="bg-[#C8A951] text-white px-6 py-2 rounded hover:bg-[#B39841] transition-colors"
          >
            Contact Us
          </button>
        </div>
      </div>
    </nav>
  );
}
