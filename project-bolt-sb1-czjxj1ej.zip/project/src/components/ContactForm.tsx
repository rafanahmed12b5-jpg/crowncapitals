import { useState } from 'react';
import { Send } from 'lucide-react';

interface ContactFormProps {
  type: 'sell' | 'general';
}

export default function ContactForm({ type }: ContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    email: '',
    phone: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setFormData({
        name: '',
        companyName: '',
        email: '',
        phone: '',
        message: '',
      });
      setSubmitted(false);
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="name" className="block text-sm font-semibold text-[#0A1A3F] mb-2">
          Name
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:border-[#C8A951] transition-colors"
        />
      </div>

      <div>
        <label htmlFor="companyName" className="block text-sm font-semibold text-[#0A1A3F] mb-2">
          Company Name
        </label>
        <input
          type="text"
          id="companyName"
          name="companyName"
          value={formData.companyName}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:border-[#C8A951] transition-colors"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="email" className="block text-sm font-semibold text-[#0A1A3F] mb-2">
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:border-[#C8A951] transition-colors"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-semibold text-[#0A1A3F] mb-2">
            Phone
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:border-[#C8A951] transition-colors"
          />
        </div>
      </div>

      <div>
        <label htmlFor="message" className="block text-sm font-semibold text-[#0A1A3F] mb-2">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          required
          rows={4}
          className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:border-[#C8A951] transition-colors resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={submitted}
        className="w-full bg-[#0A1A3F] text-white px-6 py-4 rounded font-semibold hover:bg-[#1a2f5f] transition-colors inline-flex items-center justify-center space-x-2 disabled:opacity-50"
      >
        {submitted ? (
          <span>Message Sent</span>
        ) : (
          <>
            <span>Send Message</span>
            <Send className="w-5 h-5" />
          </>
        )}
      </button>
    </form>
  );
}
