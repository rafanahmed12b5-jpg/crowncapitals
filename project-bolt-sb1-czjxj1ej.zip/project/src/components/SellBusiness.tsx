import { MessageSquare, FileSearch, Handshake } from 'lucide-react';
import ContactForm from './ContactForm';

export default function SellBusiness() {
  const steps = [
    {
      number: '01',
      icon: MessageSquare,
      title: 'Initial Confidential Discussion',
      description: 'We begin with a private conversation to understand your goals and business.',
    },
    {
      number: '02',
      icon: FileSearch,
      title: 'Business Evaluation & Strategy Review',
      description: 'Our team conducts a thorough assessment of your company and opportunities.',
    },
    {
      number: '03',
      icon: Handshake,
      title: 'Offer & Transition Planning',
      description: 'We present a fair offer and develop a seamless transition strategy.',
    },
  ];

  return (
    <section id="sell" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-[#0A1A3F] mb-6">
            Considering an Exit or Partnership?
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            We offer a confidential, transparent, and flexible acquisition process for business owners seeking succession or growth opportunities.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-12 mb-16">
          {steps.map((step) => (
            <div key={step.number} className="relative">
              <div className="text-6xl font-bold text-[#C8A951]/20 mb-4">{step.number}</div>
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-14 h-14 bg-[#0A1A3F] rounded-lg flex items-center justify-center">
                  <step.icon className="w-7 h-7 text-[#C8A951]" strokeWidth={1.5} />
                </div>
                <h3 className="text-xl font-bold text-[#0A1A3F]">{step.title}</h3>
              </div>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-xl p-8">
          <ContactForm type="sell" />
          <p className="text-sm text-gray-500 text-center mt-6 italic">
            All conversations are held in strict confidence.
          </p>
        </div>
      </div>
    </section>
  );
}
