import { Shield, Target, Users, TrendingUp } from 'lucide-react';

export default function About() {
  const values = [
    { icon: Shield, label: 'Integrity' },
    { icon: Target, label: 'Vision' },
    { icon: Users, label: 'Partnership' },
    { icon: TrendingUp, label: 'Growth' },
  ];

  return (
    <section id="about" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-[#0A1A3F] mb-6">
              Who We Are
            </h2>
            <div className="space-y-4 text-gray-700 text-lg leading-relaxed">
              <p>
                Crown Capitals Acquisition Ltd is a privately held investment and acquisition company based in the United Kingdom. We specialize in acquiring and managing established small to mid-sized businesses, helping them unlock their next stage of growth.
              </p>
              <p>
                Our philosophy is built on discipline, transparency, and long-term value creation. We collaborate closely with business owners, investors, and advisors to ensure each partnership achieves lasting success.
              </p>
            </div>
          </div>

          <div>
            <div
              className="rounded-lg overflow-hidden shadow-2xl h-96 bg-cover bg-center"
              style={{
                backgroundImage: 'url(https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=800)',
              }}
            />
          </div>
        </div>

        <div className="mt-20 grid md:grid-cols-4 gap-8">
          {values.map((value) => (
            <div key={value.label} className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#0A1A3F] rounded-full mb-4">
                <value.icon className="w-8 h-8 text-[#C8A951]" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl font-bold text-[#0A1A3F]">{value.label}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
