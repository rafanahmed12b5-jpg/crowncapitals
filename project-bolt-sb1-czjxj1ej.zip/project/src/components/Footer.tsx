import { Crown } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0A1A3F] text-white py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col items-center space-y-6">
          <div className="flex items-center space-x-3">
            <Crown className="w-8 h-8 text-[#C8A951]" strokeWidth={1.5} />
            <div>
              <div className="font-bold text-xl tracking-tight">Crown Capitals</div>
              <div className="text-xs tracking-widest text-gray-400">ACQUISITION LTD</div>
            </div>
          </div>

          <div className="text-center text-gray-400">
            <p>&copy; {currentYear} Crown Capitals Acquisition Ltd. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
