import { Mail, MapPin, Linkedin } from 'lucide-react';
import ContactForm from './ContactForm';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-[#0A1A3F] mb-6">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-700 mb-12 leading-relaxed">
              We welcome inquiries from business owners, advisors, and investors. Reach out to our team to discuss opportunities for collaboration.
            </p>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[#0A1A3F] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-[#C8A951]" />
                </div>
                <div>
                  <div className="font-semibold text-[#0A1A3F] mb-1">Email</div>
                  <a href="mailto:info@crowncapitalsacquisition.co.uk" className="text-gray-600 hover:text-[#C8A951] transition-colors">
                    info@crowncapitalsacquisition.co.uk
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[#0A1A3F] rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-[#C8A951]" />
                </div>
                <div>
                  <div className="font-semibold text-[#0A1A3F] mb-1">Location</div>
                  <div className="text-gray-600">London, United Kingdom</div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[#0A1A3F] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Linkedin className="w-6 h-6 text-[#C8A951]" />
                </div>
                <div>
                  <div className="font-semibold text-[#0A1A3F] mb-1">Connect</div>
                  <a href="#" className="text-gray-600 hover:text-[#C8A951] transition-colors">
                    LinkedIn Profile
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-8">
            <ContactForm type="general" />
          </div>
        </div>
      </div>
    </section>
  );
}
