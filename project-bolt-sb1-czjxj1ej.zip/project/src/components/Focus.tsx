import { Handshake, Building2, Settings, LineChart } from 'lucide-react';

export default function Focus() {
  const areas = [
    {
      icon: Handshake,
      title: 'Succession & Owner Exits',
      description: 'Providing smooth transitions for business owners looking to retire or pursue new ventures.',
    },
    {
      icon: Building2,
      title: 'Strategic Partnerships',
      description: 'Forming collaborative relationships that leverage our resources and expertise.',
    },
    {
      icon: Settings,
      title: 'Operational Improvement',
      description: 'Enhancing efficiency and profitability through proven methodologies.',
    },
    {
      icon: LineChart,
      title: 'Long-Term Growth Investment',
      description: 'Committed capital deployment focused on sustainable expansion.',
    },
  ];

  return (
    <section id="focus" className="py-24 bg-[#0A1A3F] text-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">What We Do</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            We focus on acquiring profitable, owner-led businesses across the UK with strong cash flow and growth potential. We look for opportunities where our experience and resources can help businesses scale sustainably.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {areas.map((area) => (
            <div
              key={area.title}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8 hover:bg-white/10 transition-all"
            >
              <area.icon className="w-12 h-12 text-[#C8A951] mb-4" strokeWidth={1.5} />
              <h3 className="text-2xl font-bold mb-3">{area.title}</h3>
              <p className="text-gray-300">{area.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <p className="text-2xl font-light italic text-[#C8A951]">
            We don't just acquire companies — we build legacies.
          </p>
        </div>
      </div>
    </section>
  );
}
