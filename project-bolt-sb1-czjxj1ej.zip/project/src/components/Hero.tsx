import { ArrowRight } from 'lucide-react';

export default function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative flex flex-col pt-20">
      <div className="relative min-h-[85vh] flex items-center justify-center">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'linear-gradient(rgba(10, 26, 63, 0.85), rgba(10, 26, 63, 0.85)), url(https://images.pexels.com/photos/2467506/pexels-photo-2467506.jpeg?auto=compress&cs=tinysrgb&w=1920)',
          }}
        />

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
            Building Long-Term Value Through Strategic Acquisitions
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto font-light">
            Crown Capitals Acquisition partners with business owners and investors to build sustainable growth across the United Kingdom.
          </p>
        </div>
      </div>

      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-[#0A1A3F] mb-3">Integrity</h3>
            <p className="text-gray-600">Building trust through transparency and discipline.</p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold text-[#0A1A3F] mb-3">Partnership</h3>
            <p className="text-gray-600">Supporting business owners in transition and growth.</p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold text-[#0A1A3F] mb-3">Excellence</h3>
            <p className="text-gray-600">Delivering results with professionalism and care.</p>
          </div>
        </div>
        <div className="text-center mt-8">
          <button
            onClick={scrollToContact}
            className="bg-[#C8A951] text-white px-8 py-4 rounded text-lg font-semibold hover:bg-[#B39841] transition-all inline-flex items-center space-x-2 group"
          >
            <span>Contact Our Team</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
