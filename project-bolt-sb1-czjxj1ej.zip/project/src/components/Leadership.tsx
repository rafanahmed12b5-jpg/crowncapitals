import { Briefcase, Calculator, Scale, Settings } from 'lucide-react';

export default function Leadership() {
  const team = [
    {
      icon: Briefcase,
      role: 'Chairman / CEO',
      description: 'Experienced M&A advisor',
    },
    {
      icon: Calculator,
      role: 'Finance Director',
      description: 'Chartered accountant background',
    },
    {
      icon: Scale,
      role: 'Legal Advisor',
      description: 'Specialist in corporate law and transactions',
    },
    {
      icon: Settings,
      role: 'Operations Partner',
      description: 'Experienced in scaling SME businesses',
    },
  ];

  return (
    <section id="leadership" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-[#0A1A3F] mb-6">
            Our Team
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Our leadership and advisory network include experienced professionals in finance, operations, and corporate development. Together, they bring decades of experience in helping businesses grow through strategic investment and disciplined execution.
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {team.map((member) => (
            <div
              key={member.role}
              className="text-center group"
            >
              <div className="relative mb-6">
                <div className="w-48 h-48 mx-auto bg-gradient-to-br from-[#0A1A3F] to-[#1a2f5f] rounded-full flex items-center justify-center group-hover:scale-105 transition-transform">
                  <member.icon className="w-20 h-20 text-[#C8A951]" strokeWidth={1.5} />
                </div>
              </div>
              <h3 className="text-xl font-bold text-[#0A1A3F] mb-2">{member.role}</h3>
              <p className="text-gray-600">{member.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
